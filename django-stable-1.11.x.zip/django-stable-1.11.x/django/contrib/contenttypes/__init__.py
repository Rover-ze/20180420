default_app_config = 'django.contrib.contenttypes.apps.ContentTypesConfig'
